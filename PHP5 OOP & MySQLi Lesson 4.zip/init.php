<?php
/*include 'libraries/classes/person.php';
include 'libraries/classes/employee.php';
include 'libraries/classes/database.php';
include 'libraries/classes/security.php';
include 'libraries/classes/math.php';
include 'libraries/classes/car.php';
*/
spl_autoload_register(function($class){
    include_once 'libraries/classes/'.$class.'.php';
});

?>