<?php  

class Math{
	public function math_method(){
		echo "this is math method<br>";
	}
}

?>