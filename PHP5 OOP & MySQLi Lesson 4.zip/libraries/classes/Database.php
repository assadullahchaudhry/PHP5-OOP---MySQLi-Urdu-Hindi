<?php  

class Database{
	public function database_method(){
		echo "this is database method<br>";
	}
}

?>