<?php  

class Person{
	public function person_method(){
		echo "this is person method<br>";
	}
}

?>