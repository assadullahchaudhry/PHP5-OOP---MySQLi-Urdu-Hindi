<?php  

class Employee{
	public function employee_method(){
		echo "this is employee method<br>";
	}
}

?>