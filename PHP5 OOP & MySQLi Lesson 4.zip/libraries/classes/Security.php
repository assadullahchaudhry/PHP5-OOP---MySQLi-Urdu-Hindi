<?php  

class Security{
	public function security_method(){
		echo "this is security method<br>";
	}
}

?>