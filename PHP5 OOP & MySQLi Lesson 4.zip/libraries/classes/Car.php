<?php  

class Car{
	public function car_method(){
		echo "this is car method<br>";
	}
}

?>