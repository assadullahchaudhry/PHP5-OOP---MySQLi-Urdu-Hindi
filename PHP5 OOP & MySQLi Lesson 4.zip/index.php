<?php  

include_once('init.php');

$person_object = new Person();
$person_object->person_method();

$employee_object = new Employee();
$employee_object->employee_method();

$database_object = new Database();
$database_object->database_method();



?>